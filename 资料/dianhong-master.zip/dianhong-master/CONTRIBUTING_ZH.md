<span style="font-size:36px;">**贡献指南**</span>

<span style="font-size:18px;">感谢您对电鸿物联操作系统的关注与支持！我们欢迎所有人为本项目贡献力量。以下为您提供参与项目贡献的相关建议与规范。</span>

**<span style="font-size:24px;">1.问题反馈</span>**

<span style="font-size:18px;">使用电鸿物联操作系统过程中如遇到问题，可在 GitHub 仓库提交 Issue。提交前请确认：查阅已存在的 Issue，避免重复提交。详细描述问题，包括预期表现与实际发生的情况。尽可能提供可复现该问题的简易示例代码。</span>


**<span style="font-size:24px;">2.功能建议</span>**

<span style="font-size:18px;">我们非常欢迎您针对 操作系统及中间件 提出新功能建议。提交前请确认：若您的建议符合的项目目标与设计理念，请提供充足的细节说明，以便我们理解您的需求及拟实现方案。</span>

**<span style="font-size:24px;">3.代码贡献</span>**
<span style="font-size:18px;">若您希望为电鸿物联操作系统贡献代码，请遵循以下流程：</span>
- （1）Fork 项目
- （2）Fork 本项目的代码仓库
- （3）创建分支
- （4）在本地新建分支，用于进行代码修改

**<span style="font-size:24px;">4.源码编译</span>**

<span style="font-size:18px;">参考《源码编译文档》，熟悉项目的源码编译流程。</span>

- <span style="font-size:18px;">代码编写</span>

<span style="font-size:18px;">编写代码并确保符合项目的编码规范。代码风格规范项目统一采用一套代码风格以保证一致性与可读性，相关规范已定义在 clang-format 配置文件中。提交代码前，请务必使用 clang-format 对代码进行格式化处理。</span>

- <span style="font-size:18px;">提交并推送</span>

<span style="font-size:18px;">提交修改内容，并推送至您 Fork 的仓库提交拉取请求（PR）,创建 Pull Request，详细说明您的修改内容及修改原因。</span>

**<span style="font-size:24px;">5.文档贡献</span>**

<span style="font-size:18px;">文档对任何开源项目的发展都至关重要。如您发现文档存在错误，或认为内容可进一步优化，欢迎提交 Issue 或 Pull Request。开发者原创声明（DCO）,参与本项目贡献，即表示您同意《开发者原创声明》条款，这意味着：您提交的代码为您原创，或您拥有提交该代码的授权。您同意您的贡献内容采用与本项目相同的开源协议进行许可。如需表明接受上述条款，您必须在提交信息中添加签名行：您可在执行提交命令时输入 git commit -s，自动添加该签名。</span>

**<span style="font-size:24px;">6.社区支持</span>**

<span style="font-size:18px;">您可以通过解答疑问、编写教程、分享示例项目等方式为社区提供支持。若您有能帮助其他开发者的相关资源，欢迎在对应社区论坛及交流群中分享。希望这份贡献指南能帮助您顺利参与电鸿物联操作系统的贡献工作。再次感谢您的支持，期待您的精彩贡献！</span>