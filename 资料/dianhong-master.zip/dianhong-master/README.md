# 电鸿物联 开源项目

**电鸿物联操作系统** 是由　**[开放原子开源基金会（OpenAtom Foundation）](https://atomgit.com/openatomfoundation)**　孵化并运营的开源项目，聚焦于 **新型电力系统和新型能源体系构建的、互联互通、开放共享的电力工业物联** 领域。

项目具备以下核心特性：
- 以OpenHarmony和openEuler为底座，结合电力终端特性，在国家开源体系下定制开发电力统一物联操作系统
- 已发布五个主要分支版本，可适配各类硬件环境
- 满足不同厂商设备多样化需求，实现广域终端统一接入和高效管理
- 互联互通、开放共享的电力工业物联体系

## 项目版本架构

![7b2e42dd8aad572dcd1583acd6cd0cdb.png](https://raw.atomgit.com/user-images/assets/8406402/7a45d8a1-c2c4-43e7-b0d0-85c5111ba5f9/7b2e42dd8aad572dcd1583acd6cd0cdb.png '7b2e42dd8aad572dcd1583acd6cd0cdb.png')
我们致力于 **共筑开源基石，共享技术成果，共建繁荣生态**。项目遵循开放、协作、共建的原则，面向开发者、企业及生态伙伴，持续推进技术演进与社区建设。

## 代码仓库

项目源码已在以下平台同步维护，内容保持一致：

* **AtomGit**：[电鸿物联](https://atomgit.com/power-iot)

💡 建议优先通过 AtomGit 参与项目协作，以获得更完整的社区与运营支持。

### 核心项目

- **嵌入式核PEE**：应用于边侧工程类设备（如台区终端、视频云节点、充电桩等）其中包含了系统、公共中间件与行业中间件源码 | [嵌入式核PEE](https://atomgit.com/power-iot/dianhong/tree/PEE)
- **标准核PHS**：应用于端侧设备（如摄像头、移动控制球机等视频设备）其中包含了系统、公共中间件与行业中间件源码 | [标准核PHS](https://atomgit.com/power-iot/dianhong/tree/PHS)
- **智能核PHR**：应用于端侧设备（如手持终端、平板、人脸门禁等）其中包含了系统、公共中间件与行业中间件源码 | [智能核PHR](https://atomgit.com/power-iot/dianhong/tree/PHR)
- **小微核PHM**：应用于端侧设备（如环境传感器、电气监测终端、蓝牙模组等）其中包含了系统、公共中间件与行业中间件源码 | [小微核PHM](https://atomgit.com/power-iot/dianhong/tree/PHM)
- **高性能核PES**：应用于边侧服务器类设备（如变电网关、智能录波器等）其中包含了系统、公共中间件与行业中间件源码 | [高性能核PES](https://atomgit.com/power-iot/dianhong/tree/PES)
## 项目治理

本项目采用开放透明的治理模式，确保社区健康可持续发展。

### 治理架构

- **技术委员会（Technical Committee, TC）**：负责项目技术方向决策、版本发布规划及重大技术议题仲裁。委员会由核心维护者组成，定期举行公开会议。
- **维护者（Maintainer）**：负责特定模块或仓库的日常维护，拥有代码审查和合并权限。维护者名单及其负责范围详见 [MAINTAINERS.md](MAINTAINERS链接)。
- **提交者（Committer）**：对项目有持续贡献的开发者，拥有代码审查权限，可协助维护者进行代码合入。
- **贡献者（Contributor）**：任何参与项目贡献的社区成员。

### 决策机制

- **日常决策**：通过 Pull Request 的代码审查流程进行技术决策，遵循"**至少2名维护者批准**"的合入原则。
- **重大变更**：涉及架构调整、API兼容性变更、大版本发布等，需提交 RFC（Request for Comments）文档，经技术委员会讨论并达成 **共识（Consensus）** 后实施。
- **争议解决**：当出现技术分歧时，由技术委员会主席协调讨论；若无法达成一致，技术委员会将进行投票表决。

## 参与贡献

我们欢迎广大开发者和开源爱好者参与 **电鸿物联** 项目建设，您可以通过 Star、Fork、提交 Issue、发起 Pull Request 等方式，共同推动项目健康、可持续发展。

### 贡献流程

1. **问题反馈**：通过 [Issues](https://atomgit.com/org/power-iot/issues) 提交 Bug 报告或功能建议。提交前请先搜索是否已有相关 Issue。
2. **开发贡献**：
   - Fork 目标仓库到个人账户
   - 创建特性分支（`git checkout -b feature/your-feature-name`）
   - 遵循项目代码规范进行开发（详见各仓库 **README.md**）
   - 提交前运行本地测试确保通过
3. **提交代码**：发起 [Pull Requests](https://atomgit.com/org/power-iot/pulls) ，填写 PR 模板，关联相关 Issue。

### 代码合入决策

所有代码合并遵循严格的质量控制流程：

- **审查要求**：PR 必须获得 **至少 2 名维护者（Maintainer）的批准（Approve）** 方可合入。涉及核心模块的变更需相关模块负责人审查。
- **CI 检查**：必须通过持续集成（CI）流水线中的所有自动化测试和代码风格检查。
- **合入权限**：仅维护者拥有向主分支合并代码的权限。维护者将在审查通过后执行合并操作。

### 代码规范

- 提交信息（Commit Message）遵循 [Conventional Commits](https://conventionalcommits.org/) 规范
- 代码风格遵循项目特定的 Lint 规则（如 ESLint、Pylint 等）
- 新增功能需包含单元测试和必要的文档更新
- 重大变更需提前在社区邮件列表或技术例会中讨论

## 开源许可

本组织包含多个开源项目，具体许可证信息请查看各项目仓库根目录下的 `LICENSE` 文件，或访问 [组织主页](https://atomgit.com/org/power-iot/repos) 浏览各项目详情。

**使用本项目源码前，请务必阅读并遵守相关许可条款。**

## 联系我们

欢迎对 电鸿物联 感兴趣的开发者、企业及生态伙伴与我们取得联系交流。

### 官方渠道

- 🌐 官方网站：[电鸿物联操作系统]( https://nwsyy.csg.cn/product/dhwl/index.html)

- 💬 开源社区：[开放原子电鸿开源社区](power-iot.openatom.tech/)

- 📱 官方公众号：

  | <img src="./assets/开放原子电鸿开源社区公众号.jpg" width="300" alt="开放原子电鸿开源社区公众号"> |
  | :----------------------------------------------------------: |
  |             **官方社区公众号**<br/>扫码关注我们              |
  | ![开放原子电鸿开源社区logo](./assets/开放原子电鸿开源社区logo.jpg) |

---

![OpenAtom Foundation](./assets/openatom-logo.svg)